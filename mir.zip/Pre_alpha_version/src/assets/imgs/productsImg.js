import felix1 from './felix1.jpg';
import kitkat from './kitkat.jpg';
import Wiskas from './Wiskas.jpg';
import RoyalChain from './RoyalChain.jpg';
import homedog from './homedog.jpg';
import toyrats from './toyrats.jpg';
import grandmix from './grandmix.jpg';
import filter from './filter.jpg';
import terrarium from './terrarium.png';





export const productsImg = [
  felix1,
  kitkat,
  Wiskas,
  RoyalChain,
  homedog,
  toyrats,
  grandmix,
  filter,
  terrarium
];