import image1 from './image 1.png';
import image2 from './image 2.png';
import image3 from './image 3.png';
import image4 from './image 4.png';
import image5 from './image 5.png';
import image6 from './image 6.png';



export const stocks = [
  image1,
  image2,
  image3,
  image4,
  image5,
  image6
];