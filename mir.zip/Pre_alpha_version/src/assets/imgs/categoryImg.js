import cat from './cat.png';
import dog from './dog.png';
import fis from './fis.png';
import liz from './liz.png';
import pop from './pop.png';
import rat from './rat.png';
import cik from './bcCikle.png';


export const categoryImg = [
  cat,
  dog,
  fis,
  liz,
  pop,
  rat,
  cik
];